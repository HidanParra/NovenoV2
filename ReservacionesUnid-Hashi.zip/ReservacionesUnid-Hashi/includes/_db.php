<?php 
require_once 'Medoo.php';

use Medoo\Medoo;
 
$db = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'softengi_ReservacionesUnid',
    'server' => 'softenginesolutions.com.mx',
    'username' => 'softengi_reserva',
    'password' => 'EofrM$PvOIqv'
]);

?>