<template>
    <div class="dashboard-content">
      <h1>USer Page</h1>
      <p>This is User page</p>
    </div>
</template>