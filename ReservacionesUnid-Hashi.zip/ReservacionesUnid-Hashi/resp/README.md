# apartados
Sistemas de apartados (Salones, auditorio, radio, cañones )

Proyecto Apartados Unid

1-	Login:
    a.	Registro de usuario: 
          i.	Nombre, apellido (obligatorio) Nombre2 y apellido 2 (opcional)
          ii.	Matricula
          iii.	Correo
          iv.	Teléfono
          v.	Campus
          vi.	Tipo de usuario:
            1.	Docente: visto únicamente de sus reservas de proyector, auditorio, radio y TV
            2.	Administrativo UNID normal (se ingresa el dato manual “campo de texto” ej: promoción, coordinador aux. etc.)
            3.	Administrador: visto de apartado de auditorio
            4.	Coordinador multimedios: vista de cabina de radio y salón de TV
            5.	Root = Sistemas (ve todo)
          vii.	Contraseña (8 digitos)
          viii.	Validar contraseña
          ix.	Sera notificado via correo cuando su usuario este habilitado para el uso del sistema.
    b.	Inicia sesión : MATRICULA Y CONTRASEÑA (UNICAMENTE CON SU MATRICULA)
2-	ALTA DE PROYECTORES:
    a.	Proyectores:
        i.	Numero de proyector
        ii.	Marca
        iii.	Modelo
        iv.	Numero de serie
        v.	Tipo de salidas
    b.	Tipo de salida
        i.	Nombre de salida (HDMI & VGA)
        c.	Cables
        i.	Numero de cable
        ii.	Tipo de cable (HDMI & VGA)
        d.	Extensiones:
        i.	Numero de extensión
        e.	Adaptador
        i.	Numero de adaptador
        ii.	Tipo de adaptador (HDMI a Vga, VGA a HDMI, ADAPTADOR DE MAC.
    f.	Bocinas
        i.	Numero de bocina
        g.	Control
        i.	Numero de control
        ii.	Tipo de control (proyector o tv)

3-	Alta de campus: (datos para ingresar manual)
    a.	Nombre: “Unid”
    b.	Tipo: Universidad o preparatoria
    c.	Campus: “Cancún”
    d.	Estado: Estados ()
    4-	Salones
    a.	Tipo de salón (clases, auditorio, cabina de radio, tv.)
    b.	Numero de salón “clases”
    c.	Salón de clases con TV (Los salones que tienen tv  no se pueden realizar apartados de igual manera los ctc no es necesario  apartarlos).
    d.	Consultar Archivo de salones.
5-	Vistas para usuario
     a.	Docente:
         i.	Puede únicamente realizar reservas de proyectores, auditorio, cabina de radio y tv; según los permisos asignados por sistemas.
        ii.	Eliminar sus reservas
        b.	Administrativo Unid normal:
        i.	Puede únicamente realizar reservas de proyectores, auditorio, cabina de radio y tv; según los permisos asignados por sistemas.
        ii.	Eliminar sus reservas.
    c.	Administrador:
        i.	Puede únicamente realizar reservas de proyectores, auditorio, cabina de radio y tv; según los permisos asignados por sistemas.
        ii.	Puede ver todas las reservas que hay de auditorio, puede aprobarlas o cancelarlas 
        iii.	Si se cancela una reserva debe ser notificado el usuario mediante el correo registrado.
    d.	Coordinador multimedio:
        i.	Puede únicamente realizar reservas de proyectores, auditorio, cabina de radio y tv; según los permisos asignados por sistemas.
        ii.	Puede ver todas las reservas que hay de cabina de radio y tv, puede aprobarlas o cancelarlas 
        iii.	Si se cancela una reserva debe ser notificado el usuario mediante el correo registrado.
    e.	ROOT: 
        i.	PUEDE VER TODAS LAS RESERVAS DE PROYECTORES, AUDITORIO, RADIO Y TV. Marcar los cañones entregados y los que fueron regresados, vero los apartados pendientes
        ii.	REALIZAR TODAS LAS ALTAS TANTO DE SALONES, PROYECTORES, AUDITORIO, RADIO, TV, etc.
        iii.	Consultar archivo de solicitud de auditorio (para verificar campos requeridos.
        iv.	Ver lista de usuario para aprobarlos 
        v.	Cambio de contraseñas
        vi.	Eliminar usuarios.

6-	Reportes
    a.	VISTA DE APARTADOS, CONSULTA POR DIA, SEMANA, MES, AÑO (FECHA)
    b.	Salón mas usado 
    c.	Y docente con mayor reserva por fechas.
    d.	SI SE LES OCURRE ALGO MAS ME DICE.
7-	RECUERDEN QUE TODO ESTO SE MOSTRARA SEGÚN EL CAMPUS (Cancún, otra sede) Y NIVEL EDUCATIVO (Universidad o preparatorio)

8-	Recuerden documentar el sistema y código y si falta algo me avisan.
OLA
