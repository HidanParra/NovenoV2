<?php 
require_once 'Medoo.php';

use Medoo\Medoo;
 
$db = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'softengi_mydb',
    'server' => 'softenginesolutions.com.mx',
    'username' => 'softengi_Unid19',
    'password' => 'Jh9dyDU*\P'
]);

?>